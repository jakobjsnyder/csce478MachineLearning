﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw3nb
{
    class ComplexCounter
    {
        public List<int> Value;
        public List<int> Count;
        public List<int> Label;

        public ComplexCounter()
        {
            Value = new List<int>();
            Count = new List<int>();
            Label = new List<int>();
        }
    }
}
